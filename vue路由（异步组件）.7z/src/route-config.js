// 同步组件a
import a from './components/a.vue'
// import b from './components/b.vue'
// 异步组件b
// 异步写法如下
const b = resolve => require(['./components/b.vue'], resolve)

export default [
    {path: '/a', component: a},
    {path: '/b', component: b}
]