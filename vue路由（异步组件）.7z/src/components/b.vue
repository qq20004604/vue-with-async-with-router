<template>
    <div>
        <div>{{msg}}</div>
    </div>
</template>
<style scoped>


</style>
<script>
    export default{
        data(){
            return {
                msg: "这里是组件B"
            }
        }
    }
</script>
