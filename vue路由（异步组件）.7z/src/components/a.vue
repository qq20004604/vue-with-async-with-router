<template>
    <div>
        <div>组件A</div>
    </div>
</template>