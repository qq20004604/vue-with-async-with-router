<template>
    <div>
        <h1>{{msg}}</h1>
        <router-link to="/a">Go to a</router-link>
        <router-link to="/b">Go to b</router-link>
        <router-view></router-view>
    </div>
</template>

<script>
    export default {
        name: 'app',
        data () {
            return {
                msg: 'Welcome to Your Vue.js App'
            }
        }
    }
</script>